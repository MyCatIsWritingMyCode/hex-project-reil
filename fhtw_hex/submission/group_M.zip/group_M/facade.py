# This is the main interface file for the Hex tournament.

# It imports the agent class from our agent file...
from .tournament_agent import TournamentAgent

# ...and creates a single, callable instance named 'Agent'.
# This is the object the debugging script will import and use.
Agent = TournamentAgent() 